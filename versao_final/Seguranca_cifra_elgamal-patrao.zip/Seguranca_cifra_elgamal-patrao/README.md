# Seguranca_cifra_el_gamal
Trabalho de Segurança da informação 2019/2
